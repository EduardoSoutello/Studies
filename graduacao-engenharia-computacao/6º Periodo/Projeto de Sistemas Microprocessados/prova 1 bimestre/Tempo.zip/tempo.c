#define _XTAL_FREQ 20000000

#include <xc.h>
#include <pic16f877a.h>

#include "lcd.h"

unsigned char unidade = 0;
unsigned char dezena = 0;
int cont = 0;




void interrupt ISR()
{
    if(INTCONbits.TMR0IF)
    {
        INTCONbits.TMR0IF = 0;
        cont++;
        if(cont > 75)
        {
            cont = 0;
            unidade++;
            if(unidade>9)
            {
                unidade = 0;
                dezena++;
            }
            if(dezena>9)
            {
                dezena = 0;
            }
        }
    }
}


void atualizaDisplay(){
    LCD_escreve(dezena+'0');
    LCD_escreve(unidade+'0');


    __delay_ms(1000);
    LCD_limpa();

}





void main(){

    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    INTCONbits.TMR0IE = 1;
    INTCONbits.TMR0IF = 0;
    ei();
    
    OPTION_REGbits.T0CS = 0;
    OPTION_REGbits.T0SE = 0;
    OPTION_REGbits.PSA = 0;
    
    OPTION_REGbits.PS0 = 1;
    OPTION_REGbits.PS1 = 1;
    OPTION_REGbits.PS2 = 1;

    
    LCD_init();
    LCD_limpa();
    LCD_linha1();
    

    while(1){
        atualizaDisplay();
        
    
    }


}
