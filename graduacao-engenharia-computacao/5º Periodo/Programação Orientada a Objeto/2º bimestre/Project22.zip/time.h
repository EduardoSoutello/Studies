#include<iostream>
#include "jogador.h"
#include<string>
using namespace std;

typedef struct
{
	string nome_time;
	Tjogadores *jogador;
	int vitorias, derrotas, empates;
}TTime;

TTime* createTTime();
string setNomeDoTime(TTime* T);
/*void getJogador(TTime* T);
void getVitorias(TTime* T);
void getDerrotas(TTime* T);
void getEmpates(TTime* T);
string getNomeDoTime(TTime* T);
void setJogador(TTime* T);
void setVitorias(TTime* T);
void setDerrotas(TTime* T);
void setEmpates(TTime* T);
void calculaScore(TTime* T);
void calculaPontos(TTime* T);*/
void libera(TTime *T)

