#include<iostream>
#include"jogador.h"

using namespace std;

Tjogadores createTjogador(int n)
{
	Tjogadores Jogador = new Tjogadores*[n];
	return *Jogador;
}
void setNome(Tjogadores* J)
{
	string Nome;
	cout << "Digite o nome do jogador" << endl;
	getline(cin, Nome);
	(*J).nome = Nome;
}
/*void setJogos(Tjogadores* J)
{
	int Jogos;
	cout<<"Digite a quantidade de jogos que atuou"<<endl;
	cin>>Jogos;
	(*J).jogos=jogos;
}
void setPontos(Tjogadores* J)
{
	int Pontos;
	cout<<"Digite o numero de pontos marcados"<<endl;
	Pontos=0;
	Pontos++;
	(*J).pontos=Pontos;
	Pontos=0;
}
void setFaltas(Tjogadores* J)
{
	int Faltas;
	cout<<"Digite o numero de faltas marcados"<<endl;
	cin>>Faltas;
	(*J).faltas=Faltas;
}
void setCartoes(Tjogadores* J)
{
	int Cartoes;
	cout<<"Digite o numero de cartoes recebidos"<<endl;
	cin>>Cartoes;
	(*J).cartoes=Cartoes;
}
void getJogos(Tjogadores* J)
{
	cout<<(*J).nome<<endl;
}
void getPontos(Tjogadores* J);
{
	cout<<(*J).pontos<<endl;
}
void getFaltas(Tjogadores* J);
{
	cout<<(*J).faltas<<endl;
}
void getCartoes(Tjogadores* J);
{
	cout<<(*J).cartoes<<endl;
}
void calculaScore(Tjogadores* J)
{
	float Score;
	Score=(4*(*J).jogos)+(6*(*J).pontos)-(0.5*(*J).faltas)-(*J).cartoes;
	(*J).score=Score;
}*/