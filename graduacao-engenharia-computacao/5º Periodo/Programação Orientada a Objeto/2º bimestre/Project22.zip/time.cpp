#include<iostream>
#include "jogador.h"
using namespace std;

TTime* createTTime()
{
	Tjogadores J
		J = createTjogador();
	TTime* Time = new TTime;
	return Time;
}
void setNomeDoTime(TTime* T)
{
	string Nome_Time;
	getline(cin, Nome_Time);
	(*T).nome_time = Nome_Time;
}
/*void setJogador(TTime* T)
{
	string NomeJ;
	cout<<"Digite o nome do jogador"<<endl;
	getline(cin,NomeJ);
	(*T)->jogador[0].nome=NomeJ;
}
void setVitorias(TTime* T)
{
	int num;
	cout<<"Digite o numero de vitorias"<<endl;
	cin>>num;
	(*T).vitorias=num;
}
void setDerrotas(TTime* T)
{
	int num;
	cout<<"Digite o numero de derrotas"<<endl;
	cin>>num;
	(*T).derrotas=num;
}
void setEmpates(TTime* T)
{
	int num;
	cout<<"Digite o numero de empates"<<endl;
	cin>>num;
	(*T).empates=num;
}
void calculaScore(TTime* T,int)
{
	float Score=0;
	int i;
	for(i=0;i<n;i++)
	{
		Score+=(*T)->jogadores.score;
	}
	cout<<Score<<endl;
}
void calculaPontos(TTime* T)
{
	float Pontos;
	Pontos=(3*(*T).vitorias)+((*J).empates);
	cout<<Pontos<<endl;
}
void getNomeDoTime(TTime* T)
{
	string Nome;
	cout<<"Digite o nome do time que deseja acessar"<<endl;
	getline(cin,Nome);
	for(i=0;i<n;i++)
	{
		if((*T).nome==Nome")
			cout<<(*T).nome<<endl;                 CONSERTA ESSA *****
		else
			cout<<"Time nao encontrado"<<endl;
	}
}
void getJogador(TTime* T)
{
	string Nome;
	cout<<"Digite o nome do time que deseja acessar"<<endl;
	getline(cin,Nome);
	for(i=0;i<n;i++)
	{
		if((*T)->jogadores.nome==Nome")
			cout<<(*T)->jogadores.nome<<endl;
		else
			cout<<"Nome nao encontrado"<<endl;
	}
}
void getVitorias(TTime* T)
{
	string nomeT;
	int i;
	getline(cin,nomeT);
	for(i=0;i<n;i++)
	{
		if((*T).nome_time==nomeT)
		{
			cout<<(*T).vitorias<<endl;
		}
		else
		{
			cout<<"Time n�o encontrado";
		}
	}
}
void getDerrotas(TTime* T)
{
	string nomeT;
	int i;
	getline(cin,nomeT);
	for(i=0;i<n;i++)
	{
		if((*T).nome_time==nomeT)
		{
			cout<<(*T).derrotas<<endl;
		}
		else
		{
			cout<<"Time n�o encontrado";
		}
	}
}
void getEmpates(TTime* T)
{
	string nomeT;
	int i;
	getline(cin,nomeT);
	for(i=0;i<n;i++)
	{
		if((*T).nome_time==nomeT)
		{
			cout<<(*T).empates<<endl;
		}
		else
		{
			cout<<"Time n�o encontrado";
		}
	}
}*/
void libera(TTime *T)
{
	Delete T;
}
