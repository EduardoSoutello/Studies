#include<iostream>
#include "jogador.h"
#include "time.h"
using namespace std;

int main()
{
	TTime T;
	T = createTTime();
	setNomeDoTime(T);
	/*getJogador(T);
	getVitorias(T);
	getDerrotas(T);
	getEmpates(T);
	getNomeDoTime(T);
	setJogador(T);
	setVitorias(T);
	setDerrotas(T);
	setEmpates(T);
	calculaScore(T);
	calculaPontos(T);
	*/
	libera(T)
		return 0;
}