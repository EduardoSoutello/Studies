#include<iostream>
#include<string>
using namespace std;

typedef struct
{
	string nome;
	int jogos, pontos, faltas, cartoes;
	float score;
}Tjogadores;

Tjogadores* createTjogador();
string getNome(Tjogadores* J);
int getJogos(Tjogadores* J);
int getPntos(Tjogadores* J);
int getFaltas(Tjogadores* J);
int getCartoes(Tjogadores* J);
void setNome(Tjogadores* J);
void setJogos(Tjogadores* J);
void setPontos(Tjogadores* J);
void setFaltas(Tjogadores* J);
void setCartoes(Tjogadores* J);
void calculaScore(Tjogadores* J); 
