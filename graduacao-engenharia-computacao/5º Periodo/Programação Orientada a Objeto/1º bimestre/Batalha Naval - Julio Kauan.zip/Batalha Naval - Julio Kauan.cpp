#include <iostream> // entrada e saida de dados.
#include <locale.h> // Sa�da de dados com acentua��o.
#include <iomanip> // Configura��o de espa�amento na sa�da de informa��o na tela.
//#include <conio.h>

constexpr auto N = 15; // Valores constantes.
constexpr auto Tlinhas = N; //Numero de linhas no tabuleiro 
constexpr auto Tcolunas = N; //Numero de Colunas no tabuleiro 
constexpr auto posmin = 66; //Numero minimo possivel de posi��es ocupadas pelas embarca��es 
constexpr auto posmax = 90; //Numero maximo possivel de posi��es ocupadas pelas embarca��es  

using namespace std;

class tabuleiro
{
public:

	int matriz[Tlinhas][Tcolunas];
	int matrizmostra[Tlinhas][Tcolunas];
	int Vida = 0;
	int limite = 0;
	int pontos = 0;

	tabuleiro() // Contrutor dos tabuleiros.
	{
		for (int i = 0; i < Tlinhas; i++)
		{
			for (int j = 0; j < Tcolunas; j++)
			{
				matriz[i][j] = 0;
				matrizmostra[i][j] = 0;
			}
		}
	}



	void mostrematriz(char nome[]) // fun��o que mostra todos as posi��es de embarca��es ocupadas do tabuleiro.
	{
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " | BATALHA NAVAL  - UNINTER 2019 - ENG COMPUTA��O |";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " |          ~ = �gua; O = Embarca��o;             |";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << endl << setw(22) << "JOGADOR " << nome << endl;
		cout << endl << "	Posi��es ocupadas do jogador : " << limite << "	M�nimo necess�rio: " << posmin << endl;
		cout << "						M�ximo poss�vel:   " << posmax << endl;
		cout << "   ";
		for (int i = 0; i < Tcolunas; i++)
		{
			cout << setw(3) << i + 1;
		}
		cout << endl;
		cout << "   ";
		for (int i = 0; i < Tcolunas; i++)
		{
			cout << setw(2) << "___";
		}
		cout << endl;
		for (int i = 0; i < Tlinhas; i++)
		{
			cout << setw(2) << i + 1 << " |";
			for (int j = 0; j < Tcolunas; j++)
			{
				{
					if (matriz[i][j] == 0)// Verifica se o c�digo deve imprimir '~' para espa�o vazio, ou, 'O' para espa�o ocupado por embarca��o.
					{
						cout << setw(2) << " ~ ";
					}
					else
					{
						cout << setw(2) << " O ";
					}
				}
			}
			cout << endl;
		}
	}

	void mostramatrizvisivel(char nome[], int vezes)
	{
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " | BATALHA NAVAL  - UNINTER 2019 - ENG COMPUTA��O |";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << " |       ~ = �gua; @ = Acerto; X = Erro;          |";
		cout << endl << " -------------------------------------------------- ";
		cout << endl << endl << setw(20) << "Atualmente disparando: JOGADOR " << nome << endl;
		cout << "						Disparos restantes:   " << vezes << endl;
		cout << "   ";
		for (int i = 0; i < Tcolunas; i++)
		{
			cout << setw(3) << i + 1;
		}
		cout << endl;
		cout << "   ";
		for (int i = 0; i < Tcolunas; i++)
		{
			cout << setw(2) << "___";
		}
		cout << endl;
		for (int i = 0; i < Tlinhas; i++)
		{
			cout << setw(2) << i + 1 << " |";
			for (int j = 0; j < Tcolunas; j++)
			{
				{
					if (matrizmostra[i][j] == 0)// Verifica quando o c�digo deve imprimir acerto"@" ou erro"X" no lugar dos lugares sem que ainda n�o levaram tiro.
					{
						cout << setw(2) << " ~ ";
					}
					else
					{
						if (matrizmostra[i][j] == 1)
						{
							cout << setw(2) << " @ ";
						}
						else
						{
							cout << setw(2) << " X ";
						}
					}
				}
			}
			cout << endl;
		}

	}

	int tiro(int line, int column)
	{
		if (matrizmostra[line][column] == 1 || matrizmostra[line][column] == 2)
		{
			cout << endl << "Voce ja atirou nesta posi��o, escolha outra posi��o por favor! >=[";
			cout << endl << "Voc� perdeu um disparo, tente n�o fazer isso denovo." << endl;
			return 0;
		}
		else
		{
			if (matriz[line][column] != 0)
			{
				switch (matriz[line][column])
				{
				case 1:
					matrizmostra[line][column] = 1;
					Vida -= 1; // Decremento na vida do jogador por posi��o acertada.
					return 10; // Pontua��o conseguida pelo tipo de embarca��o acertada.
				case 2:
					matrizmostra[line][column] = 1;
					Vida -= 1; // Decremento na vida do jogador por posi��o acertada.
					return 5; // Pontua��o conseguida pelo tipo de embarca��o acertada.
				case 3:
					matrizmostra[line][column] = 1;
					Vida -= 1; // Decremento na vida do jogador por posi��o acertada.
					return 10; // Pontua��o conseguida pelo tipo de embarca��o acertada.
				case 4:
					matrizmostra[line][column] = 1;
					Vida -= 1; // Decremento na vida do jogador por posi��o acertada.
					return 15; // Pontua��o conseguida pelo tipo de embarca��o acertada.
				case 5:
					matrizmostra[line][column] = 1;
					Vida -= 1; // Decremento na vida do jogador por posi��o acertada.
					return 10; // Pontua��o conseguida pelo tipo de embarca��o acertada.
				default:
					break;
				}
			}
		}
		matrizmostra[line][column] = 2;
		return 0;
	}

	int portaav(int line, int column, int valor) // Fun��o para posicionamento do Porta-Avi�es.
	{
		if (matriz[line][column] == 0 && matriz[line - 1][column] == 0 && matriz[line + 1][column + 1] == 0 && matriz[line + 1][column - 1] == 0) // Teste de verifica��o para espa�os dispon�vel para o porta-avi�es
		{
			matriz[line][column] = valor;
			matriz[line - 1][column] = valor;
			matriz[line + 1][column + 1] = valor;
			matriz[line + 1][column - 1] = valor;
			Vida += 4; // Incremento na vida do jogador baseado na quantidade de posi��es que s�o ocupadas pela embarca��o escolhida.
			return 4; //Retorno de valor de posi��es ocupadas pela embarca��o escolhida.
		}
		else
		{
			cout << endl << "Alguma posi��o que esta embarca��o utilizaria ja est� ocupada! Por favor digite outra posi��o" << endl;
			return 0;
		}

	}

	int submarino(int line, int column, int valor) // Fun��o para posicionamento do Submarino.
	{
		if (matriz[line][column] == 0) // Verifica se a posi��o do tabuleiro est� dispon�vel
		{
			matriz[line][column] = valor;
			Vida += 1; // Incremento na vida do jogador baseado na quantidade de posi��es que s�o ocupadas pela embarca��o escolhida.
			return 1;  //Retorno de valor de posi��es ocupadas pela embarca��o escolhida.
		}
		else
		{
			cout << endl << "Alguma posi��o que esta embarca��o utilizaria ja est� ocupada! Por favor digite outra posi��o" << endl;
			return 0;
		}
	}

	int cruzador(int line, int column, int valor) // Fun��o para posicionamento do Cruzador.
	{
		if (matriz[line][column] == 0 && matriz[line][column - 1] == 0)  // Teste de verifica��o para espa�os dispon�vel para o Cruzador.
		{
			matriz[line][column] = valor;
			matriz[line][column - 1] = valor;
			Vida += 2; // Incremento na vida do jogador baseado na quantidade de posi��es que s�o ocupadas pela embarca��o escolhida.
			return 2; //Retorno de valor de posi��es ocupadas pela embarca��o escolhida.
		}
		else
		{
			cout << endl << "Alguma posi��o que esta embarca��o utilizaria ja est� ocupada! Por favor digite outra posi��o" << endl;
			return 0;
		}
	}

	int encouracado(int line, int column, int valor) // Fun��o para posicionamento do Encoura�ado.
	{
		if (matriz[line][column] == 0 && matriz[line][column - 1] == 0 && matriz[line][column + 1] == 0)   // Teste de verifica��o para espa�os dispon�vel para o Encoura�ado.
		{
			matriz[line][column] = valor;
			matriz[line][column + 1] = valor;
			matriz[line][column - 1] = valor;
			Vida += 3; // Incremento na vida do jogador baseado na quantidade de posi��es que s�o ocupadas pela embarca��o escolhida.
			return 3;  //Retorno de valor de posi��es ocupadas pela embarca��o escolhida.
		}
		else
		{
			cout << endl << "Alguma posi��o que esta embarca��o utilizaria ja est� ocupada! Por favor digite outra posi��o" << endl;
			return 0;
		}
	}

	int hidroaviao(int line, int column, int valor) // Fun��o para posicionamento do HidroAvi�o.
	{
		if (matriz[line][column] == 0 && matriz[line + 1][column + 1] == 0 && matriz[line + 1][column - 1] == 0)   // Teste de verifica��o para espa�os dispon�vel para o Hidroavi�o.
		{
			matriz[line][column] = valor;
			matriz[line + 1][column + 1] = valor;
			matriz[line + 1][column - 1] = valor;
			return 3;  //Retorno de valor de posi��es ocupadas pela embarca��o escolhida.
		}
		else
		{
			cout << endl << "Alguma posi��o que esta embarca��o utilizaria ja est� ocupada! Por favor digite outra posi��o" << endl;
			return 0;
		}
	}

};

int main()
{
	setlocale(LC_ALL, "");

	tabuleiro playerA, playerB;// Chamada dos jogadores.
	int Linhas1, Colunas1, unidade, opcao, i, acerto;
	char nomeA[50], nomeB[50]; // Nomes para jogadores.
	cout << endl << " -------------------------------------------------- ";
	cout << endl << " | BATALHA NAVAL  - UNINTER 2019 - ENG COMPUTA��O |";
	cout << endl << " -------------------------------------------------- ";
	cout << endl << "Qual o nome do jogador 1? ";
	gets_s(nomeA);
	cout << endl << "Qual o nome do jogador 2? ";
	gets_s(nomeB);
	system("cls");
	cout << endl << "Jogador " << nomeA << " � sua vez de posicionar suas unidades!";
	cout << endl << "Pressione enter para continuar.";
	getchar();
	system("cls");

	do  //Posicionamento das embarca��es do jogador A.
	{
		playerA.mostrematriz(nomeA);

		cout << endl << "			 	UNIDADES:		";
		cout << endl << "	01 = Porta-Avi�es / 02 = Submarino / 03 = Cruzador ";
		cout << endl << "	04 = Encoura�ado / 05 Hidroavi�o / 00 = PARAR ";
		cout << endl << endl << "Escolha uma embarca��o: ";
		cin >> unidade;

		if (unidade < 0 || unidade > 5) // La�o de verifica��o para que op��o escolhida seja v�lida.
		{
			do
			{
				cout << endl << "!!Digite um numero v�lido!!: ";
				cin >> unidade;
			} while (unidade < 0 || unidade > 5);
		}

		if (unidade != 0) // Coleta da posi��o que ser� inserida a embarca��o.
		{
			do // Coleta do valor da linha.
			{
				cout << endl << "Digite uma linha(1-" << Tlinhas << "): ";
				cin >> Linhas1;
				if (Linhas1 < 1 || Linhas1 > Tlinhas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de linhas v�lido! >=[ ";
				}
			} while (Linhas1 < 1 || Linhas1 > Tlinhas);

			do // Coleta do valor da coluna.
			{
				cout << endl << "Digite uma coluna(1-" << Tcolunas << "): ";
				cin >> Colunas1;
				if (Colunas1 < 1 || Colunas1 > Tcolunas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de colunas v�lido! >=[ ";
				}
			} while (Colunas1 < 1 || Colunas1 > Tcolunas);

		}
		Linhas1 -= 1;
		Colunas1 -= 1;
		system("cls");
		switch (unidade)
		{
		case 1: //Porta-Avi�es
			if (playerA.limite > posmax - 4) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2) || Linhas1 < 1 || Linhas1 >(Tlinhas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerA.limite = (playerA.limite + playerA.portaav(Linhas1, Colunas1, unidade));
			break;
		case 2: //Submarino
			playerA.limite = (playerA.limite + playerA.submarino(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 3: //Cruzador
			if (playerA.limite > posmax - 2) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerA.limite = (playerA.limite + playerA.cruzador(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 4: //Encoura�ado
			if (playerA.limite > posmax - 3) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerA.limite = (playerA.limite + playerA.encouracado(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 5: //Hidroavi�o
			if (playerA.limite > posmax - 3) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2) || Linhas1 > (Tlinhas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerA.limite = (playerA.limite + playerA.hidroaviao(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		default:
			cout << endl << "Tem certeza que deseja parar de posicionar novas embarca��es?(1 = Sim ; 2 = N�o)" << endl;
			if (playerA.limite >= posmin) // verifica se o minimo de posi��es ocupadas � o suficiente para continuar o processo de parar de posicionar nova unidades.
			{
				do // Teste de digito v�lido da opcao.
				{
					cin >> opcao;
					if (opcao == 1)
					{
						playerA.limite = posmax; // Troca de valor para sair do la�o "do-while" principal(posicionamento de novas unidades)
					}
					else
					{
						if (opcao != 2)
						{
							system("cls");
							cout << endl << "Digite 1 ou 2    >=[" << endl;
							cout << endl << "Tem certeza que deseja parar de posicionar novas embarca��es?(1 = Sim ; 2 = N�o)" << endl;
						}
					}
				} while (opcao < 1 || opcao > 2);
			}
			else
			{
				cout << endl << endl << "!!!!! M�nimo de embarca��es ainda n�o alcan�ado!!!!!" << endl << endl;
			}
			break;
		}
	} while (playerA.limite < posmax);

	system("cls");
	cout << endl << "  # = �gua; O = Embarca��o; X = Erro; @ = Acerto" << endl;
	playerA.mostrematriz(nomeA);
	cout << endl << "Voce terminou de posicionar suas embarca��es!!";
	cout << endl << "Pressione Enter para continuar.";
	getchar();
	getchar();
	system("cls");
	cout << endl << "Jogador " << nomeB << " � sua vez de posicionar suas unidades!";
	cout << endl << "Pressione enter para continuar.";
	getchar();
	system("cls");

	do  //Posicionamento das embarca��es do jogador B.
	{
		playerB.mostrematriz(nomeB);

		cout << endl << "			 	UNIDADES:		";
		cout << endl << "	01 = Porta-Avi�es / 02 = Submarino / 03 = Cruzador ";
		cout << endl << "	04 = Encoura�ado / 05 Hidroavi�o / 00 = PARAR ";
		cout << endl << endl << "Escolha uma embarca��o: ";
		cin >> unidade;

		if (unidade < 0 || unidade > 5)
		{
			do
			{
				cout << endl << "!!Digite um numero v�lido!!: ";
				cin >> unidade;
			} while (unidade < 0 || unidade > 5);
		}

		if (unidade != 0) // Coleta da posi��o que ser� inserida a embarca��o.
		{
			do // Coleta do valor da linha.
			{
				cout << endl << "Digite uma linha(1-" << Tlinhas << "): ";
				cin >> Linhas1;
				if (Linhas1 < 1 || Linhas1 > Tlinhas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de linhas v�lido! >=[ ";
				}
			} while (Linhas1 < 1 || Linhas1 > Tlinhas);

			do // Coleta do valor da coluna.
			{
				cout << endl << "Digite uma coluna(1-" << Tcolunas << "): ";
				cin >> Colunas1;
				if (Colunas1 < 1 || Colunas1 > Tcolunas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de colunas v�lido! >=[ ";
				}
			} while (Colunas1 < 1 || Colunas1 > Tcolunas);

		}
		Linhas1 -= 1;
		Colunas1 -= 1;
		system("cls");
		switch (unidade)
		{
		case 1: //Porta-Avi�es
			if (playerB.limite > posmax - 4) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2) || Linhas1 < 1 || Linhas1 >(Tlinhas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerB.limite = (playerB.limite + playerB.portaav(Linhas1, Colunas1, unidade));
			break;
		case 2: //Submarino
			playerB.limite = (playerB.limite + playerB.submarino(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 3: //Cruzador
			if (playerB.limite > posmax - 2) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerB.limite = (playerB.limite + playerB.cruzador(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 4: //Encoura�ado
			if (playerB.limite > posmax - 3) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerB.limite = (playerB.limite + playerB.encouracado(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		case 5: //Hidroavi�o
			if (playerB.limite > posmax - 3) //Teste para que posicionamento m�ximo n�o seja excedido.
			{
				cout << endl << "Escolha impossivel! N�mero de posi��es seria excedida! " << endl;
				break;
			}
			if (Colunas1 < 1 || Colunas1 >(Tcolunas - 2) || Linhas1 > (Tlinhas - 2)) //Teste para que posicionamento seja totalmente dentro do tabuleiro.
			{
				cout << endl << "Posi��o inv�lida, parte da embarca��o ficaria fora do tabuleiro! " << endl;
				break;
			}
			playerB.limite = (playerB.limite + playerB.hidroaviao(Linhas1, Colunas1, unidade)); // Incremento na contagem de posi��es ocupadas do tabuleiro.
			break;
		default:
			cout << endl << "Tem certeza que deseja parar de posicionar novas embarca��es?(1 = Sim ; 2 = N�o)" << endl;
			if (playerB.limite >= posmin) // verifica se o minimo de posi��es ocupadas � o suficiente para continuar o processo de parar de posicionar nova unidades.
			{
				do // Teste de digito v�lido da opcao.
				{
					cin >> opcao;
					if (opcao == 1)
					{
						playerB.limite = posmax; // Troca de valor para sair do la�o "do-while" principal(posicionamento de novas unidades).
					}
					else
					{
						if (opcao != 2)
						{
							system("cls");
							cout << endl << "Digite 1 ou 2    >=[" << endl;
							cout << endl << "Tem certeza que deseja parar de posicionar novas embarca��es?(1 = Sim ; 2 = N�o)" << endl;
						}
					}
				} while (opcao < 1 || opcao > 2);
			}
			else
			{
				cout << endl << endl << "!!!!! M�nimo de embarca��es ainda n�o alcan�ado!!!!!" << endl << endl;
			}
			break;
		}
	} while (playerB.limite < posmax);

	system("cls");
	cout << endl << "  # = �gua; O = Embarca��o; X = Erro; @ = Acerto" << endl;
	playerB.mostrematriz(nomeB);
	cout << endl << "Voce terminou de posicionar suas embarca��es!!";
	cout << endl << "Pressione Enter para continuar.";
	getchar();
	system("cls");

	do // Etapa de disparos para ambos os jogadores;
	{
		i = 3;
		cout << endl << "Hora do jogardor " << nomeA << "!! � sua vez de disparar!";
		cout << endl << "Pressione Enter para continuar.";
		getchar();
		getchar();
		do
		{
			system("cls");
			playerB.mostramatrizvisivel(nomeA, i);
			cout << endl << "Pontua��o do jogador " << nomeA << ": " << playerA.pontos;
			cout << endl << "Vida do jogador " << nomeB << " restante: " << playerB.Vida << endl;
			do // Coleta do valor da linha.
			{
				cout << endl << "Digite uma linha para atacar!(1-" << Tlinhas << "): ";
				cin >> Linhas1;
				if (Linhas1 < 1 || Linhas1 > Tlinhas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de linhas v�lido! >=[ ";
				}
			} while (Linhas1 < 1 || Linhas1 > Tlinhas);

			do // Coleta do valor da coluna.
			{
				cout << endl << "Digite uma coluna para atacar!(1-" << Tcolunas << "): ";
				cin >> Colunas1;
				if (Colunas1 < 1 || Colunas1 > Tcolunas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de colunas v�lido! >=[ ";
				}
			} while (Colunas1 < 1 || Colunas1 > Tcolunas);

			Linhas1 -= 1;
			Colunas1 -= 1;
			acerto = playerB.tiro(Linhas1, Colunas1);
			playerA.pontos += acerto;

			i--;
		} while (i > 0 && playerA.Vida > 0 && playerB.Vida > 0);

		if (playerA.Vida < 1 || playerB.Vida < 1) // Teste para verificar se o jogo terminou antes do jogador B poder jogar.
		{
			i = 0;
		}
		else
		{
			i = 3;
			system("cls");
			playerB.mostramatrizvisivel(nomeA, 0);
			cout << endl << "Pontua��o do jogador " << nomeA << ": " << playerA.pontos;
			cout << endl << "Vida do jogador " << nomeB << " restante: " << playerB.Vida << endl;
			cout << endl << "Hora do jogardor " << nomeB << "!! � sua vez de disparar!";
			cout << endl << "Pressione Enter para continuar.";
			getchar();
			getchar();
			system("cls");
		}

		while (i > 0)
		{
			system("cls");
			playerA.mostramatrizvisivel(nomeB, i);
			cout << endl << "Pontua��o do jogador " << nomeB << ": " << playerB.pontos;
			cout << endl << "Vida do jogador " << nomeA << " restante: " << playerA.Vida << endl;
			do // Coleta do valor da linha.
			{
				cout << endl << "Digite uma linha para atacar!(1-" << Tlinhas << "): ";
				cin >> Linhas1;
				if (Linhas1 < 1 || Linhas1 > Tlinhas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de linhas v�lido! >=[ ";
				}
			} while (Linhas1 < 1 || Linhas1 > Tlinhas);

			do // Coleta do valor da coluna.
			{
				cout << endl << "Digite uma coluna para atacar!(1-" << Tcolunas << "): ";
				cin >> Colunas1;
				if (Colunas1 < 1 || Colunas1 > Tcolunas) // Teste para que valor da coluna seja um valor v�lido.
				{
					cout << "Digite um n�mero de colunas v�lido! >=[ ";
				}
			} while (Colunas1 < 1 || Colunas1 > Tcolunas);

			Linhas1 -= 1;
			Colunas1 -= 1;
			acerto = playerA.tiro(Linhas1, Colunas1);
			playerB.pontos = playerB.pontos + acerto;

			i--;
		}
		if (playerB.Vida > 0 && playerA.Vida > 0)
		{
			system("cls");
			playerA.mostramatrizvisivel(nomeB, i);
			cout << endl << "Pontua��o do jogador " << nomeB << ": " << playerB.pontos;
			cout << endl << "Vida do jogador " << nomeA << " restante: " << playerA.Vida << endl;
			getchar();
		}


	} while (playerA.Vida > 0 && playerB.Vida > 0);


	if (playerA.Vida == 0) // Verifica��o para quando o jogadorB for o vencedor
	{
		system("cls");
		cout << endl << "---FIM DE JOGO---";
		cout << endl << "O vencedor � o jogador " << nomeB << "!!!!!!!";
		cout << endl << "Pontua��o: " << playerB.pontos;
		cout << endl << "-----------------";
		getchar();
		getchar();
	}
	else
	{
		if (playerB.Vida == 0) //Verifica��o para quando o jogadorA for o vencedor
		{
			system("cls");
			cout << endl << "---FIM DE JOGO---";
			cout << endl << "O vencedor � o jogador " << nomeA << "!!!!!!!";
			cout << endl << "Pontua��o: " << playerA.pontos;
			cout << endl << "-----------------";
			getchar();
			getchar();
		}
	}

}