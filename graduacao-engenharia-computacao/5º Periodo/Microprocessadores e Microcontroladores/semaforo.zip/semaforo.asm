;****************************** Programa modelo ******************************
;*******                       Nome do programa                    ***********
;*****************************************************************************

;*********************  Defini��o do processador *****************************

	#include p16F877.inc 
	__config _HS_OSC & _WDT_OFF & _LVP_OFF & _PWRTE_ON 

;************************** Mem�ria de programa ******************************
 ORG     0 

RESET 
 nop             
 goto   START 
;***************************** Interrup��o **********************************
 ORG 4

;Antes de entrar na interrup��o, salva o contexto
 
 MOVWF W_TEMP ;Copy W to TEMP register
 SWAPF STATUS,W ;Swap status to be saved into W
 CLRF STATUS ;bank 0, regardless of current bank, Clears IRP,RP1,RP0
 MOVWF STATUS_TEMP ;Save status to bank zero STATUS_TEMP register
 MOVF PCLATH, W ;Only required if using pages 1, 2 and/or 3
 MOVWF PCLATH_TEMP ;Save PCLATH into W
 CLRF PCLATH ;Page zero, regardless of current page

;Rotina de Interrup��o
btfss INTCON,T0IF
goto FIM_INTERRUPCAO
bcf INTCON,T0IF
decfsz CONT,F
goto FIM_INTERRUPCAO
movlw d'76'
movwf CONT
;1s
decfsz CONT2,F
goto FIM_INTERRUPCAO
;13s
incf ESTADO,F
movlw d'1'
subwf ESTADO,W; W-ESTADO
btfsc STATUS,Z
call VERMELHO
movlw d'2'
subwf ESTADO,W; W-ESTADO
btfsc STATUS,Z
call VERDE
movlw d'3'
subwf ESTADO,W; W-ESTADO
btfsc STATUS,Z
call AMARELO
movlw d'4'
subwf ESTADO,W; W-ESTADO
btfsc STATUS,Z
call VERMELHO_NOVO











;Recuperando o contexto
FIM_INTERRUPCAO
MOVF PCLATH_TEMP, W ;Restore PCLATH
MOVWF PCLATH ;Move W into PCLATH
SWAPF STATUS_TEMP,W ;Swap STATUS_TEMP register into W
;(sets bank to original state)
MOVWF STATUS ;Move W into STATUS register
SWAPF W_TEMP,F ;Swap W_TEMP
SWAPF W_TEMP,W ;Swap W_TEMP into W

 retfie
;*************************** Inicio do programa ******************************

START 

 bsf     STATUS,RP0  ;vai para o Bank 1
 movlw   h'07'
 movwf   OPTION_REG
;*************************** Declara��o de vari�veis ******************************   
 DELAY 	 		EQU 0x20
 VEZES 	 		EQU 0x21
;Variaveis usadas para salvar contexto na interrup��o
 W_TEMP	 		EQU 0x22
 STATUS_TEMP	EQU 0x23
 PCLATH_TEMP	EQU 0x24
 CONT			EQU 0x25
 CONT2          EQU 0x26
 ESTADO         EQU 0x27
;Declare suas vari�veis aqui, a partir do endere�o 0x25



;*************************** Configura��es ******************************
 movlw   b'00000000' ; Seta PORTA como sa�da
 movwf   TRISA       
 movlw   b'00000000' ; Seta PORTD como sa�da
 movwf   TRISD       
 bcf     STATUS,RP0    ;vai para o Bank 0
 movlw   h'A0'
 movwf   INTCON
;*************************** Programa principal ******************************

movlw d'76'
movwf CONT
movlw d'13'
movwf CONT2
movlw 0x01
movwf PORTD
movlw d'1'
movwf ESTADO






MAIN 
 ;comandos
	NOP
 goto MAIN 

VERMELHO
movlw 0x01
movwf PORTD
movlw d'13'
movwf CONT2
return

VERDE
movlw 0x04
movwf PORTD
movlw d'10'
movwf CONT2
return

AMARELO
movlw 0x10
movwf PORTD
movlw d'3'
movwf CONT2
return

VERMELHO_NOVO
movlw 0x01
movwf PORTD
movlw d'13'
movwf CONT2
movlw d'1'
movwf ESTADO
return



 DELAY_US
  NOP
  NOP
  decfsz DELAY,1         
  goto DELAY_US        
  return          

 end
