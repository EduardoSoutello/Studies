ENTITY latchnivel IS
  PORT(
      d : IN BIT;
		enb : IN BIT;
		sel : IN INTEGER RANGE 3 DOWNTO 0;
		q0, q1, q2, q3 : BUFFER BIT
  );
END latchnivel;

ARCHITECTURE teste OF latchnivel IS
BEGIN
   PROCESS (d, enb, sel)
	BEGIN
	   IF (enb = '1') THEN
			IF sel = 0 THEN
				q0 <= d;
				q1 <= q1;
				q2 <= q2;
				q3 <= q3;
			ELSIF sel = 1 THEN
				q0 <= q0;
				q1 <= d;
				q2 <= q2;
				q3 <= q3;
			ELSIF sel = 2 THEN
				q0 <= q0;
				q1 <= q1;
				q2 <= d;
				q3 <= q3;
			ELSIF sel = 3 THEN
				q0 <= q0;
				q1 <= q1;
				q2 <= q2;
				q3 <= d;
			END IF;
		ELSE
			q0 <= q0;
			q1 <= q1;
			q2 <= q2;
			q3 <= q3;
		END IF;
	END PROCESS;
END teste;